﻿using CoSpace.Core.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoSpace.Infrastruture.Data
{
    public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : DbContext(options)
    {
        public DbSet<Admin> Admin { get; set; }
        public DbSet<Organization> Organization { get; set; }
        public DbSet<Role> Role { get; set; }
        public DbSet<UserType> UserType { get; set; }
        public DbSet<User> User { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);


            // Seed default Admin
            modelBuilder.Entity<Admin>().HasData(
                new Admin
                {
                    Id = 1,
                    Username = "admin",
                    Password = "admin123",  
                    Email = "admin@gmail.com",
                    FirstName = "Default",
                    LastName = "Admin",
                }
            );
        }
    }
}
